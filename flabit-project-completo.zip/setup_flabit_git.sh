#!/bin/bash

echo "📁 Criando pasta do projeto: flabit-project"
mkdir -p flabit-project && cd flabit-project

echo "📄 Criando arquivo flabit_gui_final.py"
cat <<EOF > flabit_gui_final.py
import tkinter as tk
from tkinter import ttk
import string
import random
from datetime import datetime

def gerar_flabit_seguro(padrao, mapa_fixos, quantidade=10):
    letras_numeros = list(string.ascii_lowercase + string.digits)
    simbolos = list("!@#$%^&*()_+-=[]{};:,.<>?")
    resultados = []
    for _ in range(quantidade):
        senha = ""
        for i, c in enumerate(padrao):
            if c == 'Φ':
                senha += random.choice(letras_numeros)
            elif c == 'S':
                senha += random.choice(simbolos)
            elif c == 'L':
                senha += mapa_fixos.get(i, random.choice(string.ascii_uppercase))
            elif c == 'F':
                senha += mapa_fixos.get(i, '-')
            else:
                senha += c
        resultados.append(senha)
    return resultados

class FlabitApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerador Flabit")
        self.create_widgets()

    def create_widgets(self):
        ttk.Label(self.root, text="Padrão Flabit (ex: ΦΦΦLΦ):").pack()
        self.padrao_entry = ttk.Entry(self.root, width=40)
        self.padrao_entry.pack()
        ttk.Label(self.root, text="Fixos (ex: 3:A,5:-):").pack()
        self.fixos_entry = ttk.Entry(self.root, width=40)
        self.fixos_entry.pack()
        ttk.Label(self.root, text="Quantidade:").pack()
        self.qtd_entry = ttk.Entry(self.root, width=10)
        self.qtd_entry.insert(0, "10")
        self.qtd_entry.pack()
        ttk.Button(self.root, text="Gerar", command=self.gerar).pack(pady=5)
        self.result_box = tk.Text(self.root, height=10)
        self.result_box.pack()

    def gerar(self):
        padrao = self.padrao_entry.get().strip()
        fixos_str = self.fixos_entry.get().strip()
        try:
            quantidade = int(self.qtd_entry.get())
        except:
            quantidade = 10
        mapa_fixos = {}
        if fixos_str:
            for item in fixos_str.split(','):
                idx, val = item.split(':')
                mapa_fixos[int(idx)] = val
        senhas = gerar_flabit_seguro(padrao, mapa_fixos, quantidade)
        self.result_box.delete("1.0", tk.END)
        for s in senhas:
            self.result_box.insert(tk.END, s + "\n")

if __name__ == '__main__':
    root = tk.Tk()
    app = FlabitApp(root)
    root.mainloop()
EOF

echo "📝 Criando README.md"
cat <<EOF > README.md
# FlabitCrack: Ferramenta Modular para Geração e Quebra de Senhas

Criado por Flávio M.

FlabitCrack é uma ferramenta open source que integra:

- Geração de wordlists personalizadas com padrão simbólico modular ("Flabit")
- Ataques a hashes com John the Ripper e Hashcat
- Gerador de senhas fortes baseadas no mesmo padrão Flabit

Padrão simbólico:
- Φ → letra minúscula ou número
- S → símbolo especial
- L → letra fixa definida
- F → caractere fixo universal

## Uso
- Executar: `python3 flabit_gui_final.py`
- Interface simples com botões de geração, ataque e salvamento

## Licença
MIT
EOF

echo "🔒 Criando .gitignore"
echo -e "__pycache__/\n*.pyc\n*.log" > .gitignore

echo "🧬 Inicializando repositório Git"
git init
git add .
git commit -m "🚀 Primeiro commit: GUI Flabit + Gerador seguro"

echo ""
echo "🌐 Agora vá ao GitHub e crie um novo repositório vazio:"
echo "👉 https://github.com/new"
echo "⚠️ NÃO marque README/.gitignore"
echo ""

read -p "Cole a URL HTTPS do novo repositório aqui: " repo_url
git remote add origin "$repo_url"
git branch -M main
git push -u origin main

echo "✅ Projeto Flabit publicado com sucesso!"
