# FlabitCrack: Ferramenta Modular para Geração e Quebra de Senhas

Criado por Flávio M.

FlabitCrack é uma ferramenta open source que integra:

- Geração de wordlists personalizadas com padrão simbólico modular ("Flabit")
- Ataques a hashes com John the Ripper e Hashcat
- Gerador de senhas fortes baseadas no mesmo padrão Flabit

## Padrão simbólico:
- Φ → letra minúscula ou número
- S → símbolo especial
- L → letra fixa definida
- F → caractere fixo universal

## Uso
- Executar: `python3 flabit_gui_final.py`
- Interface simples com botões de geração, ataque e salvamento

## Licença
MIT
